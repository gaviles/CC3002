package tarea.tests;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)

@Suite.SuiteClasses({
	DataProcessorTest.class,
	SparkLineTest.class,
	DotPlotProcessorTest.class,
	IntervalProcessorTest.class
})

public class Systemtester {
	@Test
	public void test() {
	}
}
