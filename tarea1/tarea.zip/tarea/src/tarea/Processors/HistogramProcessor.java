package tarea.Processors;

public interface HistogramProcessor {
	public String getHistogram();
	public void setData(String string);
	public void setData(String[] args);
}