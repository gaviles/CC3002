package tarea.Histograms;

import tarea.Histogram;
import tarea.Processors.SuperDotPlotProcessor;

public class SuperDotPlot extends Histogram {

	public SuperDotPlot() {
		textData = "";
		histogramProcessor = new SuperDotPlotProcessor();
	}
	public SuperDotPlot(String string) {
		textData = string;
		histogramProcessor = new SuperDotPlotProcessor(textData);
	}	
}
